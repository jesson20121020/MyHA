import{c_ as r}from"./card-e5d55e5b.js";function o(o){const s=r(o);return s.setHours(23,59,59,999),s}export{o as e};
