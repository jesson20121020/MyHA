/**
 * Ultra Vehicle Card Version
 * v2.7.0
 * 
 * This file is auto-generated from src/version.ts
 * DO NOT MODIFY DIRECTLY
 */

let version = "undefined";

function setVersion(value) {
  version = value;
}

// Set default version (will be overridden by card)
setVersion('2.7.0');

export { version, setVersion };